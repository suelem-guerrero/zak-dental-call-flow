// VoiceSearch.js - Handles voice search functionality using Web Speech API

class VoiceSearch {
    constructor(searchBar, stepDisplay) {
        this.searchBar = searchBar;
        this.stepDisplay = stepDisplay;
        this.isSupported = this.checkBrowserSupport();
        this.isListening = false;
        this.recognition = null;
        
        this.initializeElements();
        this.setupSpeechRecognition();
        this.bindEvents();
    }
    
    checkBrowserSupport() {
        return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    }
    
    initializeElements() {
        this.voiceBtn = document.getElementById('voiceSearchBtn');
        this.voiceStatus = document.getElementById('voiceStatus');
        
        if (!this.isSupported) {
            this.voiceBtn.style.display = 'none';
            console.warn('Speech recognition not supported in this browser');
            return;
        }
    }
    
    setupSpeechRecognition() {
        if (!this.isSupported) return;
        
        // Use the appropriate constructor
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        // Configure recognition settings
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'en-US';
        this.recognition.maxAlternatives = 3;
        
        // Event handlers
        this.recognition.onstart = () => this.handleStart();
        this.recognition.onresult = (event) => this.handleResult(event);
        this.recognition.onerror = (event) => this.handleError(event);
        this.recognition.onend = () => this.handleEnd();
        this.recognition.onnomatch = () => this.handleNoMatch();
        this.recognition.onspeechstart = () => this.handleSpeechStart();
        this.recognition.onspeechend = () => this.handleSpeechEnd();
    }
    
    bindEvents() {
        if (!this.isSupported) return;
        
        this.voiceBtn.addEventListener('click', () => this.toggleVoiceSearch());
        
        // Keyboard shortcut for voice search
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'V') {
                e.preventDefault();
                this.toggleVoiceSearch();
            }
        });
    }
    
    toggleVoiceSearch() {
        if (this.isListening) {
            this.stopListening();
        } else {
            this.startListening();
        }
    }
    
    startListening() {
        if (!this.isSupported || this.isListening) return;
        
        try {
            this.recognition.start();
            this.updateVoiceStatus('Listening... Speak now', 'listening');
            this.voiceBtn.classList.add('listening');
            this.isListening = true;
        } catch (error) {
            console.error('Error starting speech recognition:', error);
            this.showVoiceError('Could not start voice recognition');
        }
    }
    
    stopListening() {
        if (!this.isSupported || !this.isListening) return;
        
        this.recognition.stop();
    }
    
    handleStart() {
        console.log('Speech recognition started');
        this.updateVoiceStatus('Listening... Speak your search terms', 'listening');
    }
    
    handleResult(event) {
        const results = event.results;
        const lastResult = results[results.length - 1];
        
        if (lastResult.isFinal) {
            const transcript = lastResult[0].transcript.trim();
            const confidence = lastResult[0].confidence;
            
            console.log('Speech recognition result:', transcript, 'Confidence:', confidence);
            
            if (confidence > 0.3) { // Minimum confidence threshold
                this.processVoiceCommand(transcript);
                this.updateVoiceStatus(`Heard: "${transcript}"`, 'success');
            } else {
                this.updateVoiceStatus('Sorry, I didn\'t catch that clearly. Try again.', 'error');
            }
        }
    }
    
    handleError(event) {
        console.error('Speech recognition error:', event.error);
        
        let errorMessage = '';
        switch (event.error) {
            case 'no-speech':
                errorMessage = 'No speech detected. Try again.';
                break;
            case 'audio-capture':
                errorMessage = 'Microphone not available.';
                break;
            case 'not-allowed':
                errorMessage = 'Microphone permission denied.';
                break;
            case 'network':
                errorMessage = 'Network error occurred.';
                break;
            default:
                errorMessage = 'Voice recognition error occurred.';
        }
        
        this.showVoiceError(errorMessage);
    }
    
    handleEnd() {
        console.log('Speech recognition ended');
        this.isListening = false;
        this.voiceBtn.classList.remove('listening');
        
        // Auto-hide status after delay
        setTimeout(() => {
            if (this.voiceStatus.classList.contains('active')) {
                this.hideVoiceStatus();
            }
        }, 3000);
    }
    
    handleNoMatch() {
        this.updateVoiceStatus('No match found. Try speaking more clearly.', 'error');
    }
    
    handleSpeechStart() {
        this.updateVoiceStatus('Speech detected... Keep talking', 'listening');
    }
    
    handleSpeechEnd() {
        this.updateVoiceStatus('Processing your speech...', 'processing');
    }
    
    processVoiceCommand(transcript) {
        const command = transcript.toLowerCase();
        
        // Check for navigation commands
        if (this.handleNavigationCommands(command)) {
            return;
        }
        
        // Check for direct step navigation
        if (this.handleStepNavigation(command)) {
            return;
        }
        
        // Check for action commands
        if (this.handleActionCommands(command)) {
            return;
        }
        
        // Default to search
        this.performVoiceSearch(transcript);
    }
    
    handleNavigationCommands(command) {
        const navigationCommands = {
            'next': () => this.stepDisplay.goToNext(),
            'next step': () => this.stepDisplay.goToNext(),
            'previous': () => this.stepDisplay.goToPrevious(),
            'previous step': () => this.stepDisplay.goToPrevious(),
            'back': () => this.stepDisplay.goToPrevious(),
            'go back': () => this.stepDisplay.goToPrevious(),
            'first step': () => this.stepDisplay.goToStep(1),
            'last step': () => this.stepDisplay.goToStep(22),
            'bookmark': () => this.stepDisplay.toggleBookmark(),
            'bookmark this': () => this.stepDisplay.toggleBookmark(),
            'add bookmark': () => this.stepDisplay.toggleBookmark()
        };
        
        for (const [cmd, action] of Object.entries(navigationCommands)) {
            if (command.includes(cmd)) {
                action();
                this.updateVoiceStatus(`Executed: ${cmd}`, 'success');
                return true;
            }
        }
        
        return false;
    }
    
    handleStepNavigation(command) {
        // Look for "go to step X" or "step X"
        const stepMatch = command.match(/(?:go to )?step (\d+|one|two|three|four|five|six|seven|eight|nine|ten)/i);
        
        if (stepMatch) {
            let stepNumber = stepMatch[1];
            
            // Convert word numbers to digits
            const wordToNumber = {
                'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
                'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10'
            };
            
            if (wordToNumber[stepNumber.toLowerCase()]) {
                stepNumber = wordToNumber[stepNumber.toLowerCase()];
            }
            
            if (callFlowSteps[stepNumber]) {
                this.stepDisplay.goToStep(stepNumber);
                this.updateVoiceStatus(`Went to step ${stepNumber}`, 'success');
                return true;
            }
        }
        
        return false;
    }
    
    handleActionCommands(command) {
        const actionCommands = {
            'search': (cmd) => {
                const searchTerm = cmd.replace(/^search\s+/i, '');
                this.performVoiceSearch(searchTerm);
            },
            'find': (cmd) => {
                const searchTerm = cmd.replace(/^find\s+/i, '');
                this.performVoiceSearch(searchTerm);
            },
            'look for': (cmd) => {
                const searchTerm = cmd.replace(/^look for\s+/i, '');
                this.performVoiceSearch(searchTerm);
            }
        };
        
        for (const [cmd, action] of Object.entries(actionCommands)) {
            if (command.startsWith(cmd)) {
                action(command);
                return true;
            }
        }
        
        return false;
    }
    
    performVoiceSearch(searchTerm) {
        if (searchTerm && searchTerm.trim().length > 0) {
            this.searchBar.performSearch(searchTerm.trim());
            this.updateVoiceStatus(`Searching for: "${searchTerm}"`, 'success');
        } else {
            this.updateVoiceStatus('No search term provided', 'error');
        }
    }
    
    updateVoiceStatus(message, type = 'default') {
        const statusText = this.voiceStatus.querySelector('span');
        const statusIcon = this.voiceStatus.querySelector('i');
        
        statusText.textContent = message;
        
        // Update icon based on type
        const icons = {
            'listening': 'fas fa-microphone',
            'processing': 'fas fa-cog fa-spin',
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-triangle',
            'default': 'fas fa-microphone-slash'
        };
        
        statusIcon.className = icons[type] || icons['default'];
        
        // Update status class
        this.voiceStatus.className = `voice-status active ${type}`;
        
        this.showVoiceStatus();
    }
    
    showVoiceStatus() {
        this.voiceStatus.classList.add('active');
    }
    
    hideVoiceStatus() {
        this.voiceStatus.classList.remove('active');
    }
    
    showVoiceError(message) {
        this.updateVoiceStatus(message, 'error');
        this.isListening = false;
        this.voiceBtn.classList.remove('listening');
        
        // Auto-hide error after longer delay
        setTimeout(() => {
            this.hideVoiceStatus();
        }, 5000);
    }
    
    // Get voice search capabilities info
    getCapabilities() {
        if (!this.isSupported) {
            return {
                supported: false,
                reason: 'Speech recognition not supported in this browser'
            };
        }
        
        return {
            supported: true,
            features: [
                'Voice search for call flow steps',
                'Navigation commands (next, previous, go to step X)',
                'Action commands (search, find, bookmark)',
                'Direct step navigation by number',
                'Automatic search execution'
            ],
            commands: [
                '"Next step" - Go to next step',
                '"Previous step" - Go to previous step', 
                '"Go to step 5" - Jump to specific step',
                '"Bookmark this" - Bookmark current step',
                '"Search insurance" - Search for insurance-related steps',
                '"Find greeting" - Find greeting steps'
            ]
        };
    }
    
    // Get usage statistics
    getUsageStats() {
        return {
            isSupported: this.isSupported,
            isCurrentlyListening: this.isListening,
            hasPermission: this.recognition !== null
        };
    }
}

// Export for use in main app
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceSearch;
}