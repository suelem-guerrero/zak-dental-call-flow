// ProgressIndicator.js - Handles progress tracking and call timer

class ProgressIndicator {
    constructor(stepDisplay) {
        this.stepDisplay = stepDisplay;
        this.callStartTime = null;
        this.timerInterval = null;
        this.isCallActive = false;
        
        this.initializeElements();
        this.bindEvents();
        this.startCallTimer();
    }
    
    initializeElements() {
        this.progressFill = document.getElementById('progressFill');
        this.currentStepSpan = document.getElementById('currentStep');
        this.totalStepsSpan = document.getElementById('totalSteps');
        this.timerElement = document.getElementById('timer');
        
        // Set total steps
        this.totalSteps = Object.keys(callFlowSteps).length;
        this.totalStepsSpan.textContent = this.totalSteps;
    }
    
    bindEvents() {
        // Listen for step changes
        document.addEventListener('stepChanged', (e) => {
            this.updateProgress(e.detail.stepId);
        });
        
        // Timer controls
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.shiftKey && e.key === 'T') {
                e.preventDefault();
                this.toggleTimer();
            }
            if (e.ctrlKey && e.shiftKey && e.key === 'R') {
                e.preventDefault();
                this.resetTimer();
            }
        });
    }
    
    updateProgress(stepId) {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(stepId));
        
        if (currentIndex === -1) return;
        
        const progress = ((currentIndex + 1) / this.totalSteps) * 100;
        const stepNumber = currentIndex + 1;
        
        // Update progress bar
        this.progressFill.style.width = `${progress}%`;
        
        // Update step counter
        this.currentStepSpan.textContent = stepNumber;
        
        // Add visual feedback
        this.animateProgress();
        
        // Update progress color based on completion
        this.updateProgressColor(progress);
        
        // Store progress for persistence
        this.saveProgress(stepId, progress);
    }
    
    animateProgress() {
        this.progressFill.style.transition = 'width 0.5s ease-in-out';
        
        // Brief highlight effect
        this.progressFill.style.boxShadow = '0 0 10px rgba(0, 123, 255, 0.5)';
        
        setTimeout(() => {
            this.progressFill.style.boxShadow = 'none';
        }, 500);
    }
    
    updateProgressColor(progress) {
        let color;
        
        if (progress < 25) {
            color = '#dc3545'; // Red for early stages
        } else if (progress < 50) {
            color = '#ffc107'; // Yellow for quarter progress
        } else if (progress < 75) {
            color = '#17a2b8'; // Blue for half progress
        } else if (progress < 100) {
            color = '#007bff'; // Primary blue for near completion
        } else {
            color = '#28a745'; // Green for completion
        }
        
        this.progressFill.style.background = `linear-gradient(90deg, ${color}, ${this.lightenColor(color, 20)})`;
    }
    
    lightenColor(color, percent) {
        const num = parseInt(color.replace("#", ""), 16);
        const amt = Math.round(2.55 * percent);
        const R = (num >> 16) + amt;
        const G = (num >> 8 & 0x00FF) + amt;
        const B = (num & 0x0000FF) + amt;
        
        return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
            (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
            (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    }
    
    startCallTimer() {
        if (this.isCallActive) return;
        
        this.callStartTime = new Date();
        this.isCallActive = true;
        
        this.timerInterval = setInterval(() => {
            this.updateTimer();
        }, 1000);
        
        // Visual indicator that timer is running
        this.timerElement.parentElement.classList.add('timer-active');
    }
    
    stopCallTimer() {
        if (!this.isCallActive) return;
        
        this.isCallActive = false;
        
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
        
        this.timerElement.parentElement.classList.remove('timer-active');
        
        // Store final call duration
        this.saveCallDuration();
    }
    
    resetTimer() {
        this.stopCallTimer();
        this.callStartTime = new Date();
        this.updateTimer();
        this.startCallTimer();
    }
    
    toggleTimer() {
        if (this.isCallActive) {
            this.stopCallTimer();
        } else {
            this.startCallTimer();
        }
    }
    
    updateTimer() {
        if (!this.callStartTime) return;
        
        const now = new Date();
        const elapsed = now - this.callStartTime;
        
        const minutes = Math.floor(elapsed / 60000);
        const seconds = Math.floor((elapsed % 60000) / 1000);
        
        const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        this.timerElement.textContent = formattedTime;
        
        // Change color based on call duration
        this.updateTimerColor(minutes);
    }
    
    updateTimerColor(minutes) {
        const timerParent = this.timerElement.parentElement;
        
        // Remove existing timer classes
        timerParent.classList.remove('timer-short', 'timer-medium', 'timer-long', 'timer-very-long');
        
        if (minutes < 5) {
            timerParent.classList.add('timer-short');
        } else if (minutes < 10) {
            timerParent.classList.add('timer-medium');
        } else if (minutes < 20) {
            timerParent.classList.add('timer-long');
        } else {
            timerParent.classList.add('timer-very-long');
        }
    }
    
    getCallDuration() {
        if (!this.callStartTime) return 0;
        
        const now = new Date();
        return now - this.callStartTime;
    }
    
    getFormattedCallDuration() {
        const duration = this.getCallDuration();
        const minutes = Math.floor(duration / 60000);
        const seconds = Math.floor((duration % 60000) / 1000);
        
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    saveProgress(stepId, progress) {
        try {
            const progressData = {
                stepId: stepId,
                progress: progress,
                timestamp: new Date().toISOString(),
                callDuration: this.getCallDuration()
            };
            
            localStorage.setItem('callFlowProgress', JSON.stringify(progressData));
        } catch (error) {
            console.error('Error saving progress:', error);
        }
    }
    
    loadProgress() {
        try {
            const progressData = localStorage.getItem('callFlowProgress');
            return progressData ? JSON.parse(progressData) : null;
        } catch (error) {
            console.error('Error loading progress:', error);
            return null;
        }
    }
    
    saveCallDuration() {
        try {
            const callData = {
                startTime: this.callStartTime.toISOString(),
                endTime: new Date().toISOString(),
                duration: this.getCallDuration(),
                finalStep: this.stepDisplay.currentStepId,
                completedSteps: this.getCompletedSteps()
            };
            
            // Store in call history
            const callHistory = this.getCallHistory();
            callHistory.push(callData);
            
            // Keep only last 50 calls
            if (callHistory.length > 50) {
                callHistory.shift();
            }
            
            localStorage.setItem('callFlowHistory', JSON.stringify(callHistory));
        } catch (error) {
            console.error('Error saving call duration:', error);
        }
    }
    
    getCallHistory() {
        try {
            return JSON.parse(localStorage.getItem('callFlowHistory') || '[]');
        } catch (error) {
            console.error('Error loading call history:', error);
            return [];
        }
    }
    
    getCompletedSteps() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.stepDisplay.currentStepId));
        
        return stepIds.slice(0, currentIndex + 1);
    }
    
    // Get progress statistics
    getProgressStats() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.stepDisplay.currentStepId));
        const progress = ((currentIndex + 1) / this.totalSteps) * 100;
        
        return {
            currentStep: this.stepDisplay.currentStepId,
            currentIndex: currentIndex + 1,
            totalSteps: this.totalSteps,
            progressPercentage: Math.round(progress),
            callDuration: this.getCallDuration(),
            formattedDuration: this.getFormattedCallDuration(),
            isCallActive: this.isCallActive,
            stepsRemaining: this.totalSteps - (currentIndex + 1),
            averageTimePerStep: currentIndex > 0 ? this.getCallDuration() / (currentIndex + 1) : 0
        };
    }
    
    // Generate progress report
    generateProgressReport() {
        const stats = this.getProgressStats();
        const callHistory = this.getCallHistory();
        
        return {
            currentCall: stats,
            historicalData: {
                totalCalls: callHistory.length,
                averageCallDuration: this.calculateAverageCallDuration(callHistory),
                mostCommonFinalStep: this.getMostCommonFinalStep(callHistory),
                callsToday: this.getCallsToday(callHistory)
            },
            recommendations: this.generateRecommendations(stats, callHistory)
        };
    }
    
    calculateAverageCallDuration(history) {
        if (history.length === 0) return 0;
        
        const totalDuration = history.reduce((sum, call) => sum + (call.duration || 0), 0);
        return totalDuration / history.length;
    }
    
    getMostCommonFinalStep(history) {
        const stepCounts = {};
        
        history.forEach(call => {
            const step = call.finalStep;
            stepCounts[step] = (stepCounts[step] || 0) + 1;
        });
        
        let mostCommon = null;
        let maxCount = 0;
        
        Object.entries(stepCounts).forEach(([step, count]) => {
            if (count > maxCount) {
                maxCount = count;
                mostCommon = step;
            }
        });
        
        return mostCommon;
    }
    
    getCallsToday(history) {
        const today = new Date().toDateString();
        
        return history.filter(call => {
            const callDate = new Date(call.startTime).toDateString();
            return callDate === today;
        }).length;
    }
    
    generateRecommendations(stats, history) {
        const recommendations = [];
        
        // Duration recommendations
        if (stats.callDuration > 1200000) { // 20 minutes
            recommendations.push('Consider if all steps are necessary for this call type');
        }
        
        // Progress recommendations
        if (stats.progressPercentage < 50 && stats.callDuration > 600000) { // 10 minutes
            recommendations.push('Call is taking longer than expected - consider focusing on key steps');
        }
        
        // Historical recommendations
        if (history.length > 5) {
            const avgDuration = this.calculateAverageCallDuration(history);
            if (stats.callDuration > avgDuration * 1.5) {
                recommendations.push('This call is longer than your average - ensure you\'re staying on track');
            }
        }
        
        return recommendations;
    }
}

// Export for use in main app
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProgressIndicator;
}