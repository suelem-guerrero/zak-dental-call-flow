// Navigation.js - Handles navigation, bookmarks, and quick actions

class Navigation {
    constructor(stepDisplay) {
        this.stepDisplay = stepDisplay;
        
        this.initializeElements();
        this.bindEvents();
        this.populateJumpToStep();
        this.updateBookmarksList();
    }
    
    initializeElements() {
        this.jumpToStep = document.getElementById('jumpToStep');
        this.bookmarksList = document.getElementById('bookmarksList');
        this.quickActionBtns = document.querySelectorAll('.action-btn[data-search]');
    }
    
    bindEvents() {
        // Jump to step dropdown
        this.jumpToStep.addEventListener('change', (e) => {
            const stepId = e.target.value;
            if (stepId) {
                this.stepDisplay.goToStep(stepId);
                e.target.value = ''; // Reset dropdown
            }
        });
        
        // Bookmark list clicks
        this.bookmarksList.addEventListener('click', (e) => {
            const bookmarkItem = e.target.closest('.bookmark-item');
            if (bookmarkItem) {
                const stepId = bookmarkItem.dataset.stepId;
                this.stepDisplay.goToStep(stepId);
            }
        });
        
        // Quick action buttons are handled in SearchBar component
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    }
    
    populateJumpToStep() {
        // Clear existing options (except the first placeholder)
        const placeholder = this.jumpToStep.options[0];
        this.jumpToStep.innerHTML = '';
        this.jumpToStep.appendChild(placeholder);
        
        // Group steps by category
        const stepsByCategory = {};
        
        Object.values(callFlowSteps).forEach(step => {
            const category = step.category || 'General';
            if (!stepsByCategory[category]) {
                stepsByCategory[category] = [];
            }
            stepsByCategory[category].push(step);
        });
        
        // Create option groups
        Object.entries(stepsByCategory).forEach(([category, steps]) => {
            const optgroup = document.createElement('optgroup');
            optgroup.label = this.formatCategoryName(category);
            
            steps.forEach(step => {
                const option = document.createElement('option');
                option.value = step.id;
                option.textContent = `Step ${step.id}: ${step.title}`;
                optgroup.appendChild(option);
            });
            
            this.jumpToStep.appendChild(optgroup);
        });
    }
    
    formatCategoryName(category) {
        const categoryNames = {
            'greeting': '👋 Greeting & Setup',
            'information': '📝 Information Gathering',
            'location': '📍 Location & Setup',
            'scheduling': '📅 Scheduling',
            'specialty': '🏥 Specialty Referral',
            'insurance': '🏥 Insurance',
            'appointment': '📅 Appointment Type',
            'confirmation': '✅ Confirmation',
            'wrap-up': '🎯 Call Wrap-up'
        };
        
        return categoryNames[category] || `📋 ${category.charAt(0).toUpperCase() + category.slice(1)}`;
    }
    
    updateBookmarksList() {
        const bookmarks = this.stepDisplay.bookmarks || [];
        
        if (bookmarks.length === 0) {
            this.bookmarksList.innerHTML = '<li class="no-bookmarks">No bookmarks yet</li>';
            return;
        }
        
        const bookmarksHtml = bookmarks.map(stepId => {
            const step = callFlowSteps[stepId];
            if (!step) return '';
            
            return `
                <li class="bookmark-item" data-step-id="${stepId}">
                    <i class="fas fa-star"></i>
                    <span class="bookmark-title">Step ${step.id}: ${step.title}</span>
                    <button class="remove-bookmark" data-step-id="${stepId}" title="Remove bookmark">
                        <i class="fas fa-times"></i>
                    </button>
                </li>
            `;
        }).filter(html => html !== '').join('');
        
        this.bookmarksList.innerHTML = bookmarksHtml;
        
        // Bind remove bookmark events
        this.bookmarksList.querySelectorAll('.remove-bookmark').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const stepId = btn.dataset.stepId;
                this.removeBookmark(stepId);
            });
        });
    }
    
    removeBookmark(stepId) {
        const index = this.stepDisplay.bookmarks.indexOf(stepId);
        if (index > -1) {
            this.stepDisplay.bookmarks.splice(index, 1);
            this.stepDisplay.saveBookmarks();
            this.updateBookmarksList();
            
            // Update bookmark button if we're on this step
            if (this.stepDisplay.currentStepId === stepId) {
                this.stepDisplay.updateBookmarkButton();
            }
        }
    }
    
    handleKeyboardShortcuts(e) {
        // Only handle if not in input fields
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
            return;
        }
        
        switch(e.key) {
            case 'ArrowLeft':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.stepDisplay.goToPrevious();
                }
                break;
                
            case 'ArrowRight':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.stepDisplay.goToNext();
                }
                break;
                
            case 'Home':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.stepDisplay.goToStep(1);
                }
                break;
                
            case 'End':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.stepDisplay.goToStep(22);
                }
                break;
                
            case 'b':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.stepDisplay.toggleBookmark();
                }
                break;
                
            case 'g':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.focusJumpToStep();
                }
                break;
                
            // Number keys for quick step navigation
            case '1': case '2': case '3': case '4': case '5':
            case '6': case '7': case '8': case '9':
                if (e.ctrlKey && e.shiftKey) {
                    e.preventDefault();
                    const stepId = parseInt(e.key);
                    if (callFlowSteps[stepId]) {
                        this.stepDisplay.goToStep(stepId);
                    }
                }
                break;
        }
    }
    
    focusJumpToStep() {
        this.jumpToStep.focus();
    }
    
    // Get current navigation state
    getNavigationState() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.stepDisplay.currentStepId));
        
        return {
            currentStep: this.stepDisplay.currentStepId,
            currentIndex: currentIndex,
            totalSteps: stepIds.length,
            hasPrevious: currentIndex > 0,
            hasNext: currentIndex < stepIds.length - 1,
            bookmarksCount: this.stepDisplay.bookmarks.length,
            progress: Math.round(((currentIndex + 1) / stepIds.length) * 100)
        };
    }
    
    // Navigation history management
    initializeHistory() {
        this.navigationHistory = [];
        this.historyIndex = -1;
    }
    
    addToHistory(stepId) {
        // Remove any steps after current position
        this.navigationHistory = this.navigationHistory.slice(0, this.historyIndex + 1);
        
        // Add new step if it's different from the last one
        if (this.navigationHistory[this.navigationHistory.length - 1] !== stepId) {
            this.navigationHistory.push(stepId);
            this.historyIndex = this.navigationHistory.length - 1;
        }
        
        // Limit history size
        if (this.navigationHistory.length > 50) {
            this.navigationHistory.shift();
            this.historyIndex--;
        }
    }
    
    goBackInHistory() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            const stepId = this.navigationHistory[this.historyIndex];
            this.stepDisplay.goToStep(stepId);
            return true;
        }
        return false;
    }
    
    goForwardInHistory() {
        if (this.historyIndex < this.navigationHistory.length - 1) {
            this.historyIndex++;
            const stepId = this.navigationHistory[this.historyIndex];
            this.stepDisplay.goToStep(stepId);
            return true;
        }
        return false;
    }
    
    // Export navigation data
    exportNavigationData() {
        return {
            bookmarks: this.stepDisplay.bookmarks,
            currentStep: this.stepDisplay.currentStepId,
            history: this.navigationHistory,
            timestamp: new Date().toISOString()
        };
    }
    
    // Import navigation data
    importNavigationData(data) {
        try {
            if (data.bookmarks && Array.isArray(data.bookmarks)) {
                this.stepDisplay.bookmarks = data.bookmarks;
                this.stepDisplay.saveBookmarks();
                this.updateBookmarksList();
            }
            
            if (data.currentStep && callFlowSteps[data.currentStep]) {
                this.stepDisplay.goToStep(data.currentStep);
            }
            
            if (data.history && Array.isArray(data.history)) {
                this.navigationHistory = data.history;
                this.historyIndex = this.navigationHistory.length - 1;
            }
            
            return true;
        } catch (error) {
            console.error('Error importing navigation data:', error);
            return false;
        }
    }
    
    // Get help text for keyboard shortcuts
    getKeyboardShortcuts() {
        return [
            { keys: 'Ctrl + ←', description: 'Go to previous step' },
            { keys: 'Ctrl + →', description: 'Go to next step' },
            { keys: 'Ctrl + Home', description: 'Go to first step' },
            { keys: 'Ctrl + End', description: 'Go to last step' },
            { keys: 'Ctrl + B', description: 'Toggle bookmark' },
            { keys: 'Ctrl + G', description: 'Focus jump to step dropdown' },
            { keys: 'Ctrl + F', description: 'Focus search bar' },
            { keys: 'Ctrl + Shift + V', description: 'Toggle voice search' },
            { keys: 'Ctrl + Shift + [1-9]', description: 'Go to step number' },
            { keys: 'Escape', description: 'Close modals/cancel actions' }
        ];
    }
}

// Export for use in main app
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Navigation;
}