// SearchBar.js - Handles text search functionality

class SearchBar {
    constructor(stepDisplay) {
        this.stepDisplay = stepDisplay;
        this.searchHistory = this.loadSearchHistory();
        
        this.initializeElements();
        this.bindEvents();
    }
    
    initializeElements() {
        this.searchBar = document.getElementById('searchBar');
        this.searchModal = document.getElementById('searchModal');
        this.searchResults = document.getElementById('searchResults');
        this.closeSearchModal = document.getElementById('closeSearchModal');
        
        // Quick action buttons
        this.quickActionBtns = document.querySelectorAll('.action-btn[data-search]');
    }
    
    bindEvents() {
        // Search input events
        this.searchBar.addEventListener('input', this.debounce(() => this.handleSearch(), 300));
        this.searchBar.addEventListener('keydown', (e) => this.handleSearchKeydown(e));
        this.searchBar.addEventListener('focus', () => this.showSearchSuggestions());
        
        // Modal events
        this.closeSearchModal.addEventListener('click', () => this.hideSearchModal());
        this.searchModal.addEventListener('click', (e) => {
            if (e.target === this.searchModal) {
                this.hideSearchModal();
            }
        });
        
        // Quick action buttons
        this.quickActionBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const searchTerm = e.target.dataset.search;
                this.performSearch(searchTerm);
            });
        });
        
        // Global keyboard shortcut for search
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                this.focusSearch();
            }
            if (e.key === 'Escape' && this.searchModal.classList.contains('active')) {
                this.hideSearchModal();
            }
        });
    }
    
    handleSearch() {
        const query = this.searchBar.value.trim();
        
        if (query.length < 2) {
            this.hideSearchModal();
            return;
        }
        
        this.performSearch(query);
    }
    
    performSearch(query) {
        const results = this.searchSteps(query);
        
        if (results.length > 0) {
            this.displaySearchResults(results, query);
            this.showSearchModal();
            this.addToSearchHistory(query);
        } else {
            this.displayNoResults(query);
            this.showSearchModal();
        }
        
        // Update search bar if called from quick action
        if (this.searchBar.value !== query) {
            this.searchBar.value = query;
        }
    }
    
    searchSteps(query) {
        const results = [];
        const queryLower = query.toLowerCase();
        
        // Search using keywords mapping
        if (typeof searchSteps === 'function') {
            return searchSteps(query);
        }
        
        // Fallback search implementation
        for (const [stepId, step] of Object.entries(callFlowSteps)) {
            const searchableContent = [
                step.title,
                step.script.replace(/<[^>]*>/g, ''), // Remove HTML tags
                step.actions?.join(' ') || '',
                step.keywords?.join(' ') || '',
                step.category || ''
            ].join(' ').toLowerCase();
            
            if (searchableContent.includes(queryLower)) {
                const relevanceScore = this.calculateRelevance(queryLower, searchableContent, step);
                results.push({
                    stepId: stepId,
                    step: step,
                    matchType: 'content',
                    relevanceScore: relevanceScore,
                    matchedContent: this.extractMatchedContent(queryLower, searchableContent)
                });
            }
        }
        
        // Sort by relevance
        results.sort((a, b) => b.relevanceScore - a.relevanceScore);
        
        return results;
    }
    
    calculateRelevance(query, content, step) {
        let score = 0;
        
        // Higher score for title matches
        if (step.title.toLowerCase().includes(query)) {
            score += 100;
        }
        
        // Higher score for keyword matches
        if (step.keywords?.some(keyword => keyword.toLowerCase().includes(query))) {
            score += 50;
        }
        
        // Score for category matches
        if (step.category?.toLowerCase().includes(query)) {
            score += 30;
        }
        
        // Score for script matches
        if (step.script.toLowerCase().includes(query)) {
            score += 20;
        }
        
        // Score for action matches
        if (step.actions?.some(action => action.toLowerCase().includes(query))) {
            score += 15;
        }
        
        // Bonus for exact matches
        if (content.includes(query)) {
            score += 10;
        }
        
        return score;
    }
    
    extractMatchedContent(query, content) {
        const index = content.indexOf(query);
        if (index === -1) return '';
        
        const start = Math.max(0, index - 50);
        const end = Math.min(content.length, index + query.length + 50);
        
        let excerpt = content.substring(start, end);
        
        // Add ellipsis if truncated
        if (start > 0) excerpt = '...' + excerpt;
        if (end < content.length) excerpt = excerpt + '...';
        
        // Highlight the matched term
        excerpt = excerpt.replace(new RegExp(query, 'gi'), `<mark>$&</mark>`);
        
        return excerpt;
    }
    
    displaySearchResults(results, query) {
        const resultsHtml = results.map(result => `
            <div class="search-result-item" data-step-id="${result.stepId}">
                <div class="search-result-title">
                    Step ${result.step.id}: ${this.highlightMatch(result.step.title, query)}
                </div>
                <div class="search-result-content">
                    ${result.matchedContent || this.highlightMatch(result.step.script.replace(/<[^>]*>/g, '').substring(0, 100), query)}
                </div>
                <div class="search-result-meta">
                    Category: ${result.step.category || 'General'} | 
                    Match Type: ${result.matchType}
                </div>
            </div>
        `).join('');
        
        this.searchResults.innerHTML = `
            <div class="search-summary">
                Found ${results.length} result(s) for "${query}"
            </div>
            ${resultsHtml}
        `;
        
        // Bind click events to results
        this.searchResults.querySelectorAll('.search-result-item').forEach(item => {
            item.addEventListener('click', () => {
                const stepId = item.dataset.stepId;
                this.stepDisplay.goToStep(stepId);
                this.hideSearchModal();
            });
        });
    }
    
    displayNoResults(query) {
        this.searchResults.innerHTML = `
            <div class="search-no-results">
                <h4>No results found for "${query}"</h4>
                <p>Try searching for:</p>
                <ul>
                    <li>Insurance, Medicare, or benefits</li>
                    <li>Schedule, appointment, or booking</li>
                    <li>Specialty, referral, or endodontics</li>
                    <li>Greeting, callback, or wrap up</li>
                    <li>Location, office, or address</li>
                </ul>
            </div>
        `;
    }
    
    highlightMatch(text, query) {
        if (!query) return text;
        
        const regex = new RegExp(`(${query})`, 'gi');
        return text.replace(regex, '<span class="search-result-match">$1</span>');
    }
    
    showSearchSuggestions() {
        if (this.searchBar.value.trim().length === 0 && this.searchHistory.length > 0) {
            const suggestionsHtml = `
                <div class="search-suggestions">
                    <h4>Recent Searches:</h4>
                    ${this.searchHistory.slice(0, 5).map(term => `
                        <div class="search-suggestion" data-term="${term}">
                            <i class="fas fa-history"></i> ${term}
                        </div>
                    `).join('')}
                </div>
            `;
            
            this.searchResults.innerHTML = suggestionsHtml;
            this.showSearchModal();
            
            // Bind click events to suggestions
            this.searchResults.querySelectorAll('.search-suggestion').forEach(item => {
                item.addEventListener('click', () => {
                    const term = item.dataset.term;
                    this.searchBar.value = term;
                    this.performSearch(term);
                });
            });
        }
    }
    
    handleSearchKeydown(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const query = this.searchBar.value.trim();
            if (query) {
                this.performSearch(query);
            }
        } else if (e.key === 'Escape') {
            this.hideSearchModal();
            this.searchBar.blur();
        }
    }
    
    showSearchModal() {
        this.searchModal.classList.add('active');
        
        // Focus management for accessibility
        const firstResult = this.searchResults.querySelector('.search-result-item, .search-suggestion');
        if (firstResult) {
            firstResult.focus();
        }
    }
    
    hideSearchModal() {
        this.searchModal.classList.remove('active');
    }
    
    focusSearch() {
        this.searchBar.focus();
        this.searchBar.select();
    }
    
    addToSearchHistory(query) {
        // Remove existing instance
        const index = this.searchHistory.indexOf(query);
        if (index > -1) {
            this.searchHistory.splice(index, 1);
        }
        
        // Add to beginning
        this.searchHistory.unshift(query);
        
        // Limit to 10 items
        this.searchHistory = this.searchHistory.slice(0, 10);
        
        this.saveSearchHistory();
    }
    
    loadSearchHistory() {
        try {
            return JSON.parse(localStorage.getItem('callFlowSearchHistory') || '[]');
        } catch (e) {
            console.error('Error loading search history:', e);
            return [];
        }
    }
    
    saveSearchHistory() {
        try {
            localStorage.setItem('callFlowSearchHistory', JSON.stringify(this.searchHistory));
        } catch (e) {
            console.error('Error saving search history:', e);
        }
    }
    
    clearSearchHistory() {
        this.searchHistory = [];
        this.saveSearchHistory();
    }
    
    // Debounce utility function
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Get search statistics
    getSearchStats() {
        return {
            historyCount: this.searchHistory.length,
            recentSearches: this.searchHistory.slice(0, 5)
        };
    }
}

// Export for use in main app
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SearchBar;
}