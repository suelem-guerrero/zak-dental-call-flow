// StepDisplay.js - Handles the display and management of call flow steps

class StepDisplay {
    constructor() {
        this.currentStepId = 1;
        this.agentNotes = this.loadAgentNotes();
        this.bookmarks = this.loadBookmarks();
        this.callData = this.loadCallData();
        
        this.initializeElements();
        this.bindEvents();
        this.displayStep(this.currentStepId);
    }
    
    initializeElements() {
        this.stepTitle = document.getElementById('stepTitle');
        this.stepScript = document.getElementById('stepScript');
        this.stepActions = document.getElementById('stepActions');
        this.stepBranches = document.getElementById('stepBranches');
        this.stepNotes = document.getElementById('stepNotes');
        this.bookmarkBtn = document.getElementById('bookmarkBtn');
        this.prevBtn = document.getElementById('prevBtn');
        this.nextBtn = document.getElementById('nextBtn');
        this.currentStepSpan = document.getElementById('currentStep');
        this.totalStepsSpan = document.getElementById('totalSteps');
        this.progressFill = document.getElementById('progressFill');
        
        // Set total steps
        this.totalStepsSpan.textContent = Object.keys(callFlowSteps).length;
    }
    
    bindEvents() {
        this.bookmarkBtn.addEventListener('click', () => this.toggleBookmark());
        this.prevBtn.addEventListener('click', () => this.goToPrevious());
        this.nextBtn.addEventListener('click', () => this.goToNext());
        this.stepNotes.addEventListener('input', () => this.saveNotes());
        
        // Branch navigation
        this.stepBranches.addEventListener('click', (e) => {
            const branchBtn = e.target.closest('.branch-option');
            if (branchBtn) {
                const nextStep = branchBtn.dataset.nextStep;
                if (nextStep) {
                    this.goToStep(nextStep);
                }
            }
        });
    }
    
    displayStep(stepId) {
        const step = callFlowSteps[stepId];
        if (!step) {
            console.error('Step not found:', stepId);
            return;
        }
        
        this.currentStepId = stepId;
        
        // Update step content
        this.stepTitle.textContent = `Step ${step.id}: ${step.title}`;
        this.stepScript.innerHTML = this.processScript(step.script);
        
        // Display actions
        this.displayActions(step.actions);
        
        // Display branches
        this.displayBranches(step.branches);
        
        // Load notes for this step
        this.stepNotes.value = this.agentNotes[stepId] || '';
        
        // Update notes display to show accumulated information
        this.updateNotesDisplay();
        
        // Update bookmark button
        this.updateBookmarkButton();
        
        // Update navigation
        this.updateNavigation();
        
        // Update progress
        this.updateProgress();
        
        // Scroll to top
        this.stepScript.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        // Announce to screen readers
        this.announceStep(step);
    }
    
    processScript(script) {
        // Replace agent name placeholder
        const agentName = document.getElementById('agentName').value || '[YOUR NAME]';
        return script.replace(/\[AGENT NAME\]/g, agentName);
    }
    
    displayActions(actions) {
        if (!actions || actions.length === 0) {
            this.stepActions.innerHTML = '';
            return;
        }
        
        const actionsHtml = `
            <h4><i class="fas fa-tasks"></i> Actions Needed:</h4>
            <ul>
                ${actions.map(action => `<li>${action}</li>`).join('')}
            </ul>
        `;
        
        this.stepActions.innerHTML = actionsHtml;
    }
    
    displayBranches(branches) {
        if (!branches || branches.length === 0) {
            this.stepBranches.innerHTML = '';
            return;
        }
        
        const step = callFlowSteps[this.currentStepId];
        
        // Check if this is a decision tree step
        if (step.isDecisionTree) {
            const branchesHtml = `
                <h4><i class="fas fa-directions"></i> Choose Call Type:</h4>
                <div class="decision-buttons">
                    ${branches.map(branch => `
                        <button class="decision-btn ${branch.condition.toLowerCase().includes('callback') ? 'callback' : 'inbound'}" 
                                data-next-step="${branch.nextStep}">
                            <strong>${branch.condition}</strong><br>
                            <small>${branch.text}</small>
                        </button>
                    `).join('')}
                </div>
            `;
            this.stepBranches.innerHTML = branchesHtml;
            
            // Bind click events to decision buttons
            this.stepBranches.querySelectorAll('.decision-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const nextStep = btn.dataset.nextStep;
                    if (nextStep) {
                        this.goToStep(nextStep);
                    }
                });
            });
        } else {
            // Regular branch display
            const branchesHtml = `
                <h4><i class="fas fa-code-branch"></i> Next Steps:</h4>
                ${branches.map(branch => `
                    <div class="branch-option" data-next-step="${branch.nextStep}">
                        <span class="branch-condition">${branch.condition}</span>
                        <span class="branch-next">Go to Step ${branch.nextStep}</span>
                    </div>
                `).join('')}
            `;
            
            this.stepBranches.innerHTML = branchesHtml;
        }
    }
    
    updateBookmarkButton() {
        const isBookmarked = this.bookmarks.includes(this.currentStepId);
        const icon = this.bookmarkBtn.querySelector('i');
        
        if (isBookmarked) {
            icon.className = 'fas fa-star';
            this.bookmarkBtn.classList.add('bookmarked');
            this.bookmarkBtn.title = 'Remove bookmark';
        } else {
            icon.className = 'far fa-star';
            this.bookmarkBtn.classList.remove('bookmarked');
            this.bookmarkBtn.title = 'Bookmark this step';
        }
    }
    
    updateNavigation() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.currentStepId));
        
        // Update previous button
        this.prevBtn.disabled = currentIndex <= 0;
        
        // Update next button
        this.nextBtn.disabled = currentIndex >= stepIds.length - 1;
    }
    
    updateProgress() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.currentStepId));
        const progress = ((currentIndex + 1) / stepIds.length) * 100;
        
        this.progressFill.style.width = `${progress}%`;
        this.currentStepSpan.textContent = currentIndex + 1;
    }
    
    goToStep(stepId) {
        if (callFlowSteps[stepId]) {
            this.displayStep(stepId);
        }
    }
    
    goToPrevious() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.currentStepId));
        
        if (currentIndex > 0) {
            this.goToStep(stepIds[currentIndex - 1]);
        }
    }
    
    goToNext() {
        const stepIds = Object.keys(callFlowSteps);
        const currentIndex = stepIds.indexOf(String(this.currentStepId));
        
        if (currentIndex < stepIds.length - 1) {
            this.goToStep(stepIds[currentIndex + 1]);
        }
    }
    
    toggleBookmark() {
        const index = this.bookmarks.indexOf(this.currentStepId);
        
        if (index > -1) {
            this.bookmarks.splice(index, 1);
        } else {
            this.bookmarks.push(this.currentStepId);
        }
        
        this.saveBookmarks();
        this.updateBookmarkButton();
        
        // Update bookmarks display in sidebar
        if (window.navigation) {
            window.navigation.updateBookmarksList();
        }
    }
    
    saveNotes() {
        this.agentNotes[this.currentStepId] = this.stepNotes.value;
        this.saveAgentNotes();
        this.updateCallData();
    }
    
    updateCallData() {
        const step = callFlowSteps[this.currentStepId];
        const noteValue = this.stepNotes.value.trim();
        
        if (noteValue) {
            // Store structured data based on step category
            switch(step.category) {
                case 'greeting':
                    this.callData.customerConcern = noteValue;
                    break;
                case 'information':
                    if (this.currentStepId === 2) {
                        const lines = noteValue.split('\n');
                        this.callData.customerName = lines[0] || '';
                        this.callData.phoneNumber = lines[1] || '';
                        this.callData.concern = lines[2] || '';
                    } else {
                        this.callData.personalInfo = noteValue;
                    }
                    break;
                case 'location':
                    this.callData.preferredLocation = noteValue;
                    break;
                case 'insurance':
                    if (this.currentStepId === 13 || this.currentStepId === 14) {
                        this.callData.insuranceType = noteValue;
                    } else {
                        this.callData.insuranceDetails = noteValue;
                    }
                    break;
                case 'specialty':
                    this.callData.specialtyInfo = noteValue;
                    break;
                case 'appointment':
                    this.callData.appointmentInfo = noteValue;
                    break;
                case 'confirmation':
                    this.callData.appointmentDetails = noteValue;
                    break;
                default:
                    if (!this.callData.additionalNotes) this.callData.additionalNotes = [];
                    this.callData.additionalNotes.push(`Step ${this.currentStepId}: ${noteValue}`);
            }
            
            this.saveCallData();
        }
    }
    
    updateNotesDisplay() {
        const step = callFlowSteps[this.currentStepId];
        
        // Add template suggestions based on step
        let placeholder = this.getNotesPlaceholder(step);
        this.stepNotes.placeholder = placeholder;
        
        // Show final template if on last step
        if (this.currentStepId === 22) {
            this.showFinalNotesTemplate();
        }
    }
    
    getNotesPlaceholder(step) {
        const placeholders = {
            1: "Note call type selection...",
            "1a": "Customer's main concern or reason for calling...",
            "1b": "Callback reason and customer response...",
            2: "Customer Name:\nPhone Number:\nMain Concern:",
            3: "Preferred location:\nAccessibility needs:",
            5: "Specialty type (endodontics/oral surgery):\nReferring dentist:",
            6: "Insurance carrier:\nPlan type (HMO/PPO):\nIn-network status:",
            9: "Number of family members:\nNames and ages:",
            10: "Insurance status (yes/no):\nCoverage details:",
            12: "Date of birth:\nAge category:",
            13: "Medicare ID:\nMedicare Advantage (Y/N):\nMedical insurance cards needed:",
            14: "Dental insurance company:\nPolicy holder info:",
            15: "Personal information collected:\nChart creation notes:",
            16: "Insurance company:\nPolicy holder:\nReferral source:",
            17: "Appointment scheduled:\nDate/Time:\nLocation:\nSpecial instructions:",
            18: "Appointment confirmed:\nDate/Time:\nLocation:",
            21: "Additional questions asked:\nResolutions provided:",
            22: "Survey response:\nCall completion notes:"
        };
        
        return placeholders[this.currentStepId] || "Add notes for this step...";
    }
    
    showFinalNotesTemplate() {
        // Create final notes template section
        const finalTemplate = this.generateFinalTemplate();
        
        // Add template section after notes
        const templateSection = document.createElement('div');
        templateSection.className = 'final-notes-template';
        templateSection.innerHTML = `
            <h4><i class="fas fa-clipboard-list"></i> Complete Call Summary - Copy to Dental Software</h4>
            <div class="template-content">
                <textarea readonly id="finalTemplate">${finalTemplate}</textarea>
                <div class="template-actions">
                    <button class="copy-template-btn" onclick="this.copyTemplate()">
                        <i class="fas fa-copy"></i> Copy All Notes
                    </button>
                    <button class="clear-call-btn" onclick="this.clearCallData()">
                        <i class="fas fa-trash"></i> Clear Call Data
                    </button>
                </div>
            </div>
        `;
        
        // Insert after step notes
        const notesSection = document.querySelector('.step-notes');
        if (!document.querySelector('.final-notes-template')) {
            notesSection.parentNode.insertBefore(templateSection, notesSection.nextSibling);
        }
        
        // Bind copy function
        const copyBtn = templateSection.querySelector('.copy-template-btn');
        copyBtn.addEventListener('click', () => this.copyTemplate());
        
        const clearBtn = templateSection.querySelector('.clear-call-btn');
        clearBtn.addEventListener('click', () => this.clearCallData());
    }
    
    generateFinalTemplate() {
        const data = this.callData;
        const agentName = document.getElementById('agentName')?.value || '[Agent Name]';
        const callDate = new Date().toLocaleDateString();
        const callTime = new Date().toLocaleTimeString();
        
        return `=== ZAK DENTAL CALL SUMMARY ===
Date: ${callDate}
Time: ${callTime}
Agent: ${agentName}

CUSTOMER INFORMATION:
Name: ${data.customerName || '[Not provided]'}
Phone: ${data.phoneNumber || '[Not provided]'}
Primary Concern: ${data.customerConcern || data.concern || '[Not provided]'}

LOCATION & PREFERENCES:
Preferred Location: ${data.preferredLocation || '[Not specified]'}

SPECIALTY REFERRAL:
${data.specialtyInfo || 'No specialty referral'}

INSURANCE INFORMATION:
Type: ${data.insuranceType || '[Not provided]'}
Details: ${data.insuranceDetails || '[Not provided]'}

APPOINTMENT DETAILS:
${data.appointmentInfo || '[Not scheduled]'}
${data.appointmentDetails || ''}

PERSONAL INFORMATION:
${data.personalInfo || '[Not collected]'}

ADDITIONAL NOTES:
${data.additionalNotes ? data.additionalNotes.join('\n') : 'No additional notes'}

CALL OUTCOME:
${this.agentNotes[22] || 'Call completed successfully'}

=== END SUMMARY ===

STEP-BY-STEP NOTES:
${Object.entries(this.agentNotes).map(([stepId, note]) => {
    const step = callFlowSteps[stepId];
    return note.trim() ? `Step ${stepId} (${step?.title || 'Unknown'}): ${note}` : '';
}).filter(note => note).join('\n')}`;
    }
    
    copyTemplate() {
        const template = document.getElementById('finalTemplate');
        if (template) {
            template.select();
            document.execCommand('copy');
            
            // Show success message
            const copyBtn = document.querySelector('.copy-template-btn');
            const originalText = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
            copyBtn.style.backgroundColor = '#28a745';
            
            setTimeout(() => {
                copyBtn.innerHTML = originalText;
                copyBtn.style.backgroundColor = '';
            }, 2000);
        }
    }
    
    clearCallData() {
        if (confirm('Are you sure you want to clear all call data? This cannot be undone.')) {
            this.callData = this.initializeCallData();
            this.agentNotes = {};
            this.saveCallData();
            this.saveAgentNotes();
            
            // Remove template section
            const templateSection = document.querySelector('.final-notes-template');
            if (templateSection) {
                templateSection.remove();
            }
            
            // Go back to step 1
            this.displayStep(1);
        }
    }
    
    initializeCallData() {
        return {
            callDate: new Date().toISOString(),
            customerName: '',
            phoneNumber: '',
            customerConcern: '',
            concern: '',
            preferredLocation: '',
            specialtyInfo: '',
            insuranceType: '',
            insuranceDetails: '',
            appointmentInfo: '',
            appointmentDetails: '',
            personalInfo: '',
            additionalNotes: []
        };
    }
    
    loadCallData() {
        try {
            const saved = localStorage.getItem('currentCallData');
            return saved ? JSON.parse(saved) : this.initializeCallData();
        } catch (error) {
            console.error('Error loading call data:', error);
            return this.initializeCallData();
        }
    }
    
    saveCallData() {
        try {
            localStorage.setItem('currentCallData', JSON.stringify(this.callData));
        } catch (error) {
            console.error('Error saving call data:', error);
        }
    }
    
    loadAgentNotes() {
        try {
            return JSON.parse(localStorage.getItem('callFlowNotes') || '{}');
        } catch (e) {
            console.error('Error loading agent notes:', e);
            return {};
        }
    }
    
    saveAgentNotes() {
        try {
            localStorage.setItem('callFlowNotes', JSON.stringify(this.agentNotes));
        } catch (e) {
            console.error('Error saving agent notes:', e);
        }
    }
    
    loadBookmarks() {
        try {
            return JSON.parse(localStorage.getItem('callFlowBookmarks') || '[]');
        } catch (e) {
            console.error('Error loading bookmarks:', e);
            return [];
        }
    }
    
    saveBookmarks() {
        try {
            localStorage.setItem('callFlowBookmarks', JSON.stringify(this.bookmarks));
        } catch (e) {
            console.error('Error saving bookmarks:', e);
        }
    }
    
    announceStep(step) {
        // Create announcement for screen readers
        const announcement = `Step ${step.id}: ${step.title}. ${step.actions ? step.actions.length + ' actions required.' : ''}`;
        
        // Create or update live region
        let liveRegion = document.getElementById('stepAnnouncement');
        if (!liveRegion) {
            liveRegion = document.createElement('div');
            liveRegion.id = 'stepAnnouncement';
            liveRegion.setAttribute('aria-live', 'polite');
            liveRegion.setAttribute('aria-atomic', 'true');
            liveRegion.style.position = 'absolute';
            liveRegion.style.left = '-10000px';
            liveRegion.style.width = '1px';
            liveRegion.style.height = '1px';
            liveRegion.style.overflow = 'hidden';
            document.body.appendChild(liveRegion);
        }
        
        liveRegion.textContent = announcement;
    }
    
    // Export current step data
    exportStepData() {
        const step = callFlowSteps[this.currentStepId];
        return {
            stepId: this.currentStepId,
            step: step,
            notes: this.agentNotes[this.currentStepId] || '',
            isBookmarked: this.bookmarks.includes(this.currentStepId)
        };
    }
    
    // Get step statistics
    getStepStats() {
        const totalSteps = Object.keys(callFlowSteps).length;
        const notesCount = Object.keys(this.agentNotes).length;
        const bookmarksCount = this.bookmarks.length;
        
        return {
            totalSteps,
            notesCount,
            bookmarksCount,
            currentStep: this.currentStepId,
            completionPercentage: Math.round((Object.keys(callFlowSteps).indexOf(String(this.currentStepId)) + 1) / totalSteps * 100)
        };
    }
    
    // Handle keyboard navigation
    handleKeyboardNavigation(event) {
        switch(event.key) {
            case 'ArrowLeft':
                if (event.ctrlKey) {
                    event.preventDefault();
                    this.goToPrevious();
                }
                break;
            case 'ArrowRight':
                if (event.ctrlKey) {
                    event.preventDefault();
                    this.goToNext();
                }
                break;
            case 'b':
                if (event.ctrlKey) {
                    event.preventDefault();
                    this.toggleBookmark();
                }
                break;
        }
    }
}

// Export for use in main app
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StepDisplay;
}