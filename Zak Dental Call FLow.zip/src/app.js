// app.js - Main application entry point

class CallFlowApp {
    constructor() {
        this.currentTheme = this.loadTheme();
        this.components = {};
        
        this.initializeApp();
    }
    
    initializeApp() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }
    
    init() {
        this.applyTheme(this.currentTheme);
        this.initializeComponents();
        this.bindGlobalEvents();
        this.loadAgentName();
        this.checkFirstTimeUser();
        
        console.log('Call Flow App initialized successfully');
    }
    
    initializeComponents() {
        try {
            this.components.stepDisplay = new StepDisplay();
            this.components.searchBar = new SearchBar(this.components.stepDisplay);
            this.components.voiceSearch = new VoiceSearch(this.components.searchBar, this.components.stepDisplay);
            this.components.navigation = new Navigation(this.components.stepDisplay);
            this.components.progressIndicator = new ProgressIndicator(this.components.stepDisplay);
            
            window.navigation = this.components.navigation;
            
        } catch (error) {
            console.error('Error initializing components:', error);
            this.showErrorMessage('Failed to initialize application components');
        }
    }
    
    bindGlobalEvents() {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
        
        const agentNameInput = document.getElementById('agentName');
        if (agentNameInput) {
            agentNameInput.addEventListener('input', () => this.saveAgentName());
            agentNameInput.addEventListener('change', () => this.updateAgentNameInSteps());
        }
        
        document.addEventListener('keydown', (e) => this.handleGlobalKeyboard(e));
        window.addEventListener('beforeunload', () => this.saveAppState());
        document.addEventListener('visibilitychange', () => this.handleVisibilityChange());
        
        window.addEventListener('beforeunload', (e) => {
            if (this.components.progressIndicator && this.components.progressIndicator.isCallActive) {
                e.preventDefault();
                e.returnValue = 'You have an active call. Are you sure you want to leave?';
                return e.returnValue;
            }
        });
    }
    
    handleGlobalKeyboard(e) {
        if (e.key === 'F1' || (e.ctrlKey && e.key === '?')) {
            e.preventDefault();
            this.showHelpDialog();
        }
        
        if (e.ctrlKey && e.shiftKey && e.key === 'T' && !e.altKey) {
            e.preventDefault();
            this.toggleTheme();
        }
    }
    
    toggleTheme() {
        const themes = ['light', 'dark', 'blue', 'professional', 'high-contrast'];
        const currentIndex = themes.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % themes.length;
        
        this.currentTheme = themes[nextIndex];
        this.applyTheme(this.currentTheme);
        this.saveTheme();
        
        this.showNotification(`Switched to ${this.currentTheme} theme`);
    }
    
    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            const icon = themeToggle.querySelector('i');
            const themeIcons = {
                'light': 'fas fa-sun',
                'dark': 'fas fa-moon',
                'blue': 'fas fa-palette',
                'professional': 'fas fa-briefcase',
                'high-contrast': 'fas fa-adjust'
            };
            
            icon.className = themeIcons[theme] || 'fas fa-palette';
            themeToggle.title = `Current theme: ${theme}`;
        }
    }
    
    saveTheme() {
        try {
            localStorage.setItem('callFlowTheme', this.currentTheme);
        } catch (error) {
            console.error('Error saving theme:', error);
        }
    }
    
    loadTheme() {
        try {
            return localStorage.getItem('callFlowTheme') || 'light';
        } catch (error) {
            console.error('Error loading theme:', error);
            return 'light';
        }
    }
    
    saveAgentName() {
        const agentNameInput = document.getElementById('agentName');
        if (agentNameInput) {
            try {
                localStorage.setItem('agentName', agentNameInput.value);
            } catch (error) {
                console.error('Error saving agent name:', error);
            }
        }
    }
    
    loadAgentName() {
        try {
            const savedName = localStorage.getItem('agentName');
            const agentNameInput = document.getElementById('agentName');
            
            if (savedName && agentNameInput) {
                agentNameInput.value = savedName;
                this.updateAgentNameInSteps();
            }
        } catch (error) {
            console.error('Error loading agent name:', error);
        }
    }
    
    updateAgentNameInSteps() {
        if (this.components.stepDisplay) {
            this.components.stepDisplay.displayStep(this.components.stepDisplay.currentStepId);
        }
    }
    
    checkFirstTimeUser() {
        try {
            const isFirstTime = !localStorage.getItem('callFlowFirstVisit');
            
            if (isFirstTime) {
                localStorage.setItem('callFlowFirstVisit', 'false');
                
                setTimeout(() => {
                    this.showWelcomeMessage();
                }, 1000);
            }
        } catch (error) {
            console.error('Error checking first time user:', error);
        }
    }
    
    showWelcomeMessage() {
        this.showNotification(
            'Welcome to Zak Dental Call Flow! Press F1 for help or use the microphone button for voice search.',
            'info',
            8000
        );
    }
    
    showHelpDialog() {
        const helpContent = `
            <div class="help-dialog">
                <h3><i class="fas fa-question-circle"></i> Call Flow Help</h3>
                
                <div class="help-section">
                    <h4>Navigation</h4>
                    <ul>
                        <li><strong>Ctrl + ←/→:</strong> Previous/Next step</li>
                        <li><strong>Ctrl + Home/End:</strong> First/Last step</li>
                        <li><strong>Ctrl + G:</strong> Jump to step</li>
                        <li><strong>Ctrl + B:</strong> Bookmark current step</li>
                    </ul>
                </div>
                
                <div class="help-section">
                    <h4>Search</h4>
                    <ul>
                        <li><strong>Ctrl + F:</strong> Focus search bar</li>
                        <li><strong>Ctrl + Shift + V:</strong> Voice search</li>
                        <li><strong>Type keywords:</strong> insurance, schedule, specialty, etc.</li>
                    </ul>
                </div>
                
                <div class="help-section">
                    <h4>Voice Commands</h4>
                    <ul>
                        <li>"Next step" - Go to next step</li>
                        <li>"Go to step 5" - Jump to specific step</li>
                        <li>"Bookmark this" - Bookmark current step</li>
                        <li>"Search insurance" - Find insurance steps</li>
                    </ul>
                </div>
            </div>
        `;
        
        this.showModal('Help', helpContent);
    }
    
    handleVisibilityChange() {
        if (document.hidden) {
            this.saveAppState();
        }
    }
    
    saveAppState() {
        try {
            const appState = {
                currentStep: this.components.stepDisplay?.currentStepId,
                theme: this.currentTheme,
                timestamp: new Date().toISOString()
            };
            
            localStorage.setItem('callFlowAppState', JSON.stringify(appState));
        } catch (error) {
            console.error('Error saving app state:', error);
        }
    }
    
    showNotification(message, type = 'info', duration = 5000) {
        console.log(`Notification: ${message}`);
        // Basic notification implementation for now
    }
    
    showModal(title, content) {
        console.log(`Modal: ${title}`);
        // Basic modal implementation for now
    }
    
    showErrorMessage(message) {
        console.error('App Error:', message);
    }
}

// Initialize the app when the script loads
const app = new CallFlowApp();

// Make app globally available for debugging
window.callFlowApp = app;