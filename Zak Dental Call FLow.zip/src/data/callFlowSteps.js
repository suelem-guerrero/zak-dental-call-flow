// Call Flow Steps Data
const callFlowSteps = {
    1: {
        id: 1,
        title: "Call Type Selection",
        category: "greeting",
        script: `<strong>WELCOME TO ZAK DENTAL CALL FLOW</strong><br>
        Please select the type of call you are handling:`,
        actions: [
            "Listen to determine call type",
            "Select appropriate greeting below"
        ],
        branches: [
            { condition: "New Inbound Call", nextStep: "1a", text: "Customer calling in for first time or new inquiry" },
            { condition: "Callback Request", nextStep: "1b", text: "Returning a callback to customer" }
        ],
        keywords: ["greeting", "call type", "inbound", "callback"],
        notes: "",
        isDecisionTree: true
    },
    "1a": {
        id: "1a",
        title: "Basic Greeting - Inbound",
        category: "greeting",
        script: `<strong>INBOUND GREETING:</strong><br>
        "Thank you for choosing Zak Dental, my name is <span class="agent-placeholder">[AGENT NAME]</span> and I can help you!"`,
        actions: [
            "Listen to caller's initial concern",
            "Be warm and professional",
            "Prepare to gather information"
        ],
        branches: [
            { condition: "Greeting completed", nextStep: 2, text: "Continue to gather caller info" }
        ],
        keywords: ["greeting", "hello", "inbound", "thank you", "name"],
        notes: ""
    },
    "1b": {
        id: "1b",
        title: "Basic Greeting - Callback",
        category: "greeting", 
        script: `<strong>CALLBACK GREETING:</strong><br>
        "Hi, my name is <span class="agent-placeholder">[AGENT NAME]</span> from Zak Dental and I'm actually returning a callback request. How can I help you?"`,
        actions: [
            "Reference their callback request",
            "Listen to their concern",
            "Be professional and helpful"
        ],
        branches: [
            { condition: "Continue", nextStep: 2, text: "Proceed to gather caller information" }
        ],
        keywords: ["callback", "returning", "help", "greeting"],
        notes: ""
    },
    2: {
        id: 2,
        title: "Gather Caller Information",
        category: "information",
        script: `<strong>GATHER CALLER DETAILS:</strong><br>
        • Take note of the concern<br>
        • Get caller's name<br>
        • Get phone number (only ask if not shown in Caller ID)`,
        actions: [
            "Write down their main concern",
            "Ask: 'May I have your name please?'",
            "Verify phone number if not in Caller ID",
            "Confirm spelling of name"
        ],
        branches: [
            { condition: "Information gathered", nextStep: 3, text: "Continue to location confirmation" }
        ],
        keywords: ["name", "phone", "caller", "information", "concern"],
        notes: ""
    },
    3: {
        id: 3,
        title: "Confirm Location",
        category: "location",
        script: `<strong>LOCATION CONFIRMATION:</strong><br>
        "Which of our locations would be most convenient for you?"`,
        actions: [
            "Listen to their preferred location",
            "Confirm the address",
            "Note any accessibility needs"
        ],
        branches: [
            { condition: "Location confirmed", nextStep: 4, text: "Check if ready to schedule" },
            { condition: "Caller unsure", nextStep: "3b", text: "Help them choose location" }
        ],
        keywords: ["location", "office", "convenient", "address"],
        notes: ""
    },
    "3b": {
        id: "3b", 
        title: "Help Choose Location",
        category: "location",
        script: `<strong>LOCATION ASSISTANCE:</strong><br>
        "Let me help you find the most convenient location. What area are you located in?"`,
        actions: [
            "Ask for their general area/city",
            "Provide 2-3 closest options",
            "Mention driving times if helpful",
            "Highlight any special services at locations"
        ],
        branches: [
            { condition: "Location decided", nextStep: 4, text: "Continue to scheduling readiness" }
        ],
        keywords: ["location help", "area", "closest", "driving"],
        notes: ""
    },
    4: {
        id: 4,
        title: "Ready to Schedule Check",
        category: "scheduling",
        script: `<strong>SCHEDULING READINESS:</strong><br>
        "Ok so lets get you scheduled in our (fill in desired location) office"`,
        actions: [
            "Fill in the specific location they chose",
            "Proceed with confidence to scheduling process"
        ],
        branches: [
            { condition: "Ready to schedule", nextStep: 5, text: "Continue to specialty check" },
            { condition: "Not ready", nextStep: "4b", text: "Handle not ready to schedule" }
        ],
        keywords: ["schedule", "appointment", "ready", "today"],
        notes: ""
    },
    "4b": {
        id: "4b",
        title: "Not Ready to Schedule",
        category: "scheduling",
        script: `<strong>NOT READY TO SCHEDULE:</strong><br>
        "I understand. What information can I provide to help you make a decision?"`,
        actions: [
            "Listen to their concerns",
            "Provide requested information",
            "Offer to call back when ready",
            "Get their preferred contact method"
        ],
        branches: [
            { condition: "Now ready", nextStep: 5, text: "Continue to specialty check" },
            { condition: "Call back later", nextStep: 21, text: "Go to wrap up" }
        ],
        keywords: ["not ready", "information", "call back", "concerns"],
        notes: ""
    },
    5: {
        id: 5,
        title: "Verify Specialty Referral",
        category: "specialty",
        script: `<strong>SPECIALTY REFERRAL CHECK:</strong><br>
        "<span class="caller-name">[Caller name]</span>, before we proceed, may I ask if you've been referred to us from another dental office for any specialty services, such as endodontics or oral surgery?"`,
        actions: [
            "Wait for clear yes/no answer",
            "Listen for specialty type mentioned"
        ],
        branches: [
            { condition: "YES - Referred for specialty", nextStep: 6, text: "Handle specialty referral" },
            { condition: "NO - Regular appointment", nextStep: 9, text: "Skip to appointment type" }
        ],
        keywords: ["specialty", "referral", "endodontics", "oral surgery", "referred"],
        notes: ""
    },
    6: {
        id: 6,
        title: "Specialty Insurance Verification",
        category: "specialty",
        script: `<strong>SPECIALTY INSURANCE:</strong><br>
        "Perfect, before we get started, may I confirm your insurance carrier and plan name so I can make sure we're in-network for both the specialist and the facility before we schedule?"`,
        actions: [
            "Get insurance carrier name",
            "Get plan name (HMO/PPO)",
            "Check Monday Board and payer list",
            "Verify in-network status"
        ],
        branches: [
            { condition: "In-Network", nextStep: 7, text: "Handle in-network specialty" },
            { condition: "Out-of-Network", nextStep: "7b", text: "Handle out-of-network" },
            { condition: "Unable to confirm", nextStep: "7c", text: "Request insurance photos" }
        ],
        keywords: ["insurance", "carrier", "in-network", "specialty", "plan"],
        notes: ""
    },
    7: {
        id: 7,
        title: "In-Network Specialty",
        category: "specialty",
        script: `<strong>IN-NETWORK SPECIALTY:</strong><br>
        "Great news, we are in-network for your plan. To get everything ready, please send a photo of your referral and your medical and dental insurance cards (front and back) to contact@zakdental.com."`,
        actions: [
            "Wait for confirmation they can send photos",
            "Confirm email address: contact@zakdental.com",
            "Ask if they have referral on hand"
        ],
        branches: [
            { condition: "Referral on hand", nextStep: 8, text: "Continue with referral" },
            { condition: "Need to get referral", nextStep: "8b", text: "Handle missing referral" }
        ],
        keywords: ["in-network", "referral", "insurance cards", "contact@zakdental.com"],
        notes: ""
    },
    "7b": {
        id: "7b",
        title: "Out-of-Network Specialty", 
        category: "specialty",
        script: `<strong>OUT-OF-NETWORK:</strong><br>
        "Thanks for confirming. It looks like this plan is out-of-network for the specialist at our facility. We recommend you contact your insurance to find an in-network provider to maximize your benefits."`,
        actions: [
            "Explain out-of-network costs",
            "Suggest calling insurance for alternatives",
            "Offer to help if they want to proceed anyway"
        ],
        branches: [
            { condition: "Want to proceed anyway", nextStep: 8, text: "Continue despite out-of-network" },
            { condition: "Will find in-network provider", nextStep: 21, text: "Go to wrap up call" }
        ],
        keywords: ["out-of-network", "insurance", "in-network provider", "benefits"],
        notes: ""
    },
    "7c": {
        id: "7c",
        title: "Unable to Confirm Insurance",
        category: "specialty", 
        script: `<strong>UNCLEAR INSURANCE:</strong><br>
        "To make sure we place you with the right provider, could you email us a clear photo of the front and back of your insurance card to contact@zakdental.com? We'll verify benefits and get right back to you with next steps."`,
        actions: [
            "Confirm email address",
            "Ask for clear photos of both sides",
            "Set expectation for callback timing"
        ],
        branches: [
            { condition: "Will send photos", nextStep: 8, text: "Continue to scheduling question" },
            { condition: "Cannot send photos", nextStep: 21, text: "Schedule callback and wrap up" }
        ],
        keywords: ["unclear", "insurance card", "photos", "verify benefits"],
        notes: ""
    },
    8: {
        id: 8,
        title: "Specialty Scheduling Question",
        category: "specialty",
        script: `<strong>SPECIALTY SCHEDULING:</strong><br>
        "While you are doing that, are you looking to schedule an appointment for yourself or someone else?"`,
        actions: [
            "Wait for response",
            "Note if for self or family member",
            "Get patient name if different from caller"
        ],
        branches: [
            { condition: "Response received", nextStep: 9, text: "Continue to appointment type" }
        ],
        keywords: ["scheduling", "yourself", "someone else", "appointment"],
        notes: ""
    },
    "8b": {
        id: "8b",
        title: "Missing Referral Handling",
        category: "specialty",
        script: `<strong>MISSING REFERRAL:</strong><br>
        "You'll need to get the referral from your referring dentist first. This can be a physical paper or a referral code. Once you have it, please call us back."`,
        actions: [
            "Explain referral requirement",
            "Give them office number to call back",
            "Offer to help with any questions"
        ],
        branches: [
            { condition: "Will get referral", nextStep: 21, text: "Go to wrap up call" }
        ],
        keywords: ["missing referral", "referring dentist", "call back"],
        notes: ""
    },
    9: {
        id: 9,
        title: "Single vs Multiple Appointments",
        category: "appointment",
        script: `<strong>APPOINTMENT COUNT:</strong><br>
        "<span class="caller-name">[Caller name]</span>, are you looking to schedule an appointment for yourself or someone else?"`,
        actions: [
            "Listen for single vs multiple family members",
            "If multiple, get names of all patients",
            "Confirm ages if children involved"
        ],
        branches: [
            { condition: "Single appointment", nextStep: 10, text: "Continue to insurance status" },
            { condition: "Multiple family members", nextStep: "9b", text: "Handle multiple appointments" }
        ],
        keywords: ["yourself", "someone else", "family", "multiple", "appointments"],
        notes: ""
    },
    "9b": {
        id: "9b",
        title: "Multiple Family Appointments",
        category: "appointment", 
        script: `<strong>MULTIPLE FAMILY MEMBERS:</strong><br>
        "I'll be happy to help schedule appointments for your family. Can you give me the names of everyone who needs an appointment?"`,
        actions: [
            "Write down all patient names",
            "Note relationship to caller", 
            "Confirm ages, especially for children",
            "Ask if same day preferred"
        ],
        branches: [
            { condition: "All names collected", nextStep: 10, text: "Continue to insurance status" }
        ],
        keywords: ["family", "multiple", "names", "children", "same day"],
        notes: ""
    },
    10: {
        id: 10,
        title: "Insurance Status Check",
        category: "insurance",
        script: `<strong>INSURANCE STATUS:</strong><br>
        "I am happy to help you with that. Will you be using dental insurance for this visit?"`,
        actions: [
            "Wait for clear yes/no answer",
            "Note insurance vs self-pay"
        ],
        branches: [
            { condition: "YES - Has insurance", nextStep: 12, text: "Continue to age-based insurance" },
            { condition: "NO - No insurance", nextStep: 11, text: "Handle no insurance" }
        ],
        keywords: ["insurance", "dental insurance", "self-pay", "visit"],
        notes: ""
    },
    11: {
        id: 11,
        title: "No Insurance Pathway", 
        category: "scheduling",
        script: `<strong>NO INSURANCE:</strong><br>
        "No problem at all. Let me find you the next available appointment."`,
        actions: [
            "Choose the location",
            "Look for next availability", 
            "Offer soonest available time slot",
            "Explain self-pay options"
        ],
        branches: [
            { condition: "Appointment scheduled", nextStep: 15, text: "Skip to personal info gathering" }
        ],
        keywords: ["no insurance", "self-pay", "available", "appointment"],
        notes: ""
    },
    12: {
        id: 12,
        title: "Age-Based Insurance Determination",
        category: "insurance",
        script: `<strong>AGE-BASED INSURANCE:</strong><br>
        What is the patient's date of birth?`,
        actions: [
            "Get date of birth",
            "Calculate age",
            "Determine Medicare vs regular dental"
        ],
        branches: [
            { condition: "DOB 1959 and below (65+)", nextStep: 13, text: "Handle Medicare insurance" },
            { condition: "DOB 1960 and up (under 65)", nextStep: 14, text: "Handle regular dental insurance" }
        ],
        keywords: ["date of birth", "age", "medicare", "1959", "1960"],
        notes: ""
    },
    13: {
        id: 13,
        title: "Medicare Insurance (65+)",
        category: "insurance",
        script: `<strong>MEDICARE PATIENT (65+):</strong><br>
        "I'll need to gather your Medicare information to verify benefits."`,
        actions: [
            "Get insurance phone number",
            "Get SSN or Medicare Insurance ID",
            "Ask: 'Is this Medicare Advantage? (Y/N)'",
            "Remind: 'Please bring all medical insurance cards to appointment'"
        ],
        branches: [
            { condition: "Medicare info gathered", nextStep: 15, text: "Continue to personal information" }
        ],
        keywords: ["medicare", "ssn", "medicare advantage", "medical insurance", "65"],
        notes: "If patient hesitant about SSN: 'We need to verify your Medicare benefits to get answers to your questions, so we're gathering it now to review benefits at exam time.'"
    },
    14: {
        id: 14,
        title: "Regular Dental Insurance (Under 65)",
        category: "insurance",
        script: `<strong>DENTAL INSURANCE (UNDER 65):</strong><br>
        "I'll gather your dental insurance information."`,
        actions: [
            "Get insurance phone number",
            "Get Insurance ID or SSN",
            "Note insurance carrier name",
            "Verify HMO vs PPO"
        ],
        branches: [
            { condition: "Dental insurance gathered", nextStep: 15, text: "Continue to personal information" }
        ],
        keywords: ["dental insurance", "insurance id", "hmo", "ppo", "under 65"],
        notes: ""
    },
    15: {
        id: 15,
        title: "Personal Information Collection",
        category: "information",
        script: `<strong>PERSONAL INFORMATION:</strong><br>
        "Now that I scheduled the appointment(s), I need to gather your personal and insurance information to enter them in your chart(s). Please remain on the line so that I can secure this appointment properly."`,
        actions: [
            "Follow Denticon prompts",
            "Get all required personal details",
            "Create patient chart correctly",
            "Verify all information"
        ],
        branches: [
            { condition: "Personal info complete", nextStep: 16, text: "Continue to detailed insurance" }
        ],
        keywords: ["personal information", "chart", "denticon", "secure appointment"],
        notes: ""
    },
    16: {
        id: 16,
        title: "Detailed Insurance Information",
        category: "insurance",
        script: `<strong>DETAILED INSURANCE INFO:</strong><br>
        "I need to collect your complete insurance details."`,
        actions: [
            "Insurance Company Name",
            "Insurance Type (HMO or PPO)", 
            "Policy Holder Name",
            "Policy Holder DOB",
            "Insurance Phone Number",
            "Policy Holder ID or SSN",
            "Referral Source: 'How did you hear about us?'"
        ],
        branches: [
            { condition: "All insurance details collected", nextStep: 17, text: "Continue to appointment recap" }
        ],
        keywords: ["insurance company", "policy holder", "referral source", "hmo", "ppo"],
        notes: "Be sure to select referral source in Denticon"
    },
    17: {
        id: 17,
        title: "Appointment Recap (3+ Days)",
        category: "confirmation",
        script: `<strong>APPOINTMENT RECAP (MORE THAN 3 DAYS):</strong><br>
        Confirm appointment time, date, and location.`,
        actions: [
            "Read back appointment details clearly",
            "Send intake paperwork via phone and email",
            "Give 48-hour notice requirement",
            "List what to bring: Picture ID, insurance cards"
        ],
        branches: [
            { condition: "Patient pregnant", nextStep: "17b", text: "Add pregnancy instructions" },
            { condition: "Standard confirmation", nextStep: 21, text: "Continue to wrap up" }
        ],
        keywords: ["appointment recap", "intake paperwork", "48 hour notice", "picture id"],
        notes: "Script: 'I'll send your intake paperwork to both your phone and email right after this call. Filling it out ahead helps keep check-in smooth without extra wait time.'"
    },
    "17b": {
        id: "17b",
        title: "Pregnancy Instructions (3+ Days)",
        category: "confirmation",
        script: `<strong>PREGNANCY INSTRUCTIONS:</strong><br>
        "Also important, for the well-being of you and your baby, please secure a medical clearance from your doctor and bring it to your appointment for us to proceed."`,
        actions: [
            "Emphasize medical clearance requirement",
            "Confirm they understand",
            "Note pregnancy in chart"
        ],
        branches: [
            { condition: "Instructions understood", nextStep: 21, text: "Continue to wrap up" }
        ],
        keywords: ["pregnancy", "medical clearance", "doctor", "baby"],
        notes: ""
    },
    18: {
        id: 18,
        title: "Appointment Recap (Less than 3 Days)",
        category: "confirmation",
        script: `<strong>APPOINTMENT RECAP (LESS THAN 3 DAYS):</strong><br>
        Confirm appointment time, date, and location.`,
        actions: [
            "Read back appointment details clearly",
            "Mark appointment as confirmed",
            "Send intake paperwork via phone and email", 
            "List what to bring: Picture ID, insurance cards"
        ],
        branches: [
            { condition: "Patient pregnant", nextStep: "18b", text: "Add pregnancy instructions" },
            { condition: "Standard confirmation", nextStep: 21, text: "Continue to wrap up" }
        ],
        keywords: ["less than 3 days", "confirmed", "intake paperwork", "picture id"],
        notes: "No 48-hour notice needed for appointments less than 3 days out"
    },
    "18b": {
        id: "18b", 
        title: "Pregnancy Instructions (Less than 3 Days)",
        category: "confirmation",
        script: `<strong>PREGNANCY INSTRUCTIONS:</strong><br>
        "Also important, for the well-being of you and your baby, please secure a medical clearance from your doctor and bring it to your appointment for us to proceed."`,
        actions: [
            "Emphasize medical clearance requirement",
            "Confirm they understand", 
            "Note pregnancy in chart"
        ],
        branches: [
            { condition: "Instructions understood", nextStep: 21, text: "Continue to wrap up" }
        ],
        keywords: ["pregnancy", "medical clearance", "doctor", "baby"],
        notes: ""
    },
    21: {
        id: 21,
        title: "Additional Help Offer",
        category: "wrap-up",
        script: `<strong>ADDITIONAL HELP:</strong><br>
        "<span class="caller-name">[Caller name]</span>, is there anything else that we can help you with?"`,
        actions: [
            "Wait for response",
            "Address any additional questions",
            "Provide helpful information as needed"
        ],
        branches: [
            { condition: "No additional help needed", nextStep: 22, text: "Continue to survey request" },
            { condition: "Additional questions", nextStep: "21b", text: "Handle additional questions" }
        ],
        keywords: ["anything else", "help", "additional", "questions"],
        notes: ""
    },
    "21b": {
        id: "21b",
        title: "Handle Additional Questions",
        category: "wrap-up",
        script: `<strong>ADDITIONAL QUESTIONS:</strong><br>
        Address the caller's additional questions or concerns.`,
        actions: [
            "Listen carefully to their questions",
            "Provide accurate information",
            "Offer to transfer if needed",
            "Ensure all concerns are addressed"
        ],
        branches: [
            { condition: "All questions answered", nextStep: 22, text: "Continue to survey request" }
        ],
        keywords: ["additional questions", "concerns", "transfer", "information"],
        notes: ""
    },
    22: {
        id: 22,
        title: "Survey Request & Call End",
        category: "wrap-up", 
        script: `<strong>SURVEY REQUEST:</strong><br>
        "Before we end the call, can I ask you for a small favor? I'd appreciate it if you could stay on the line to rate us about your experience with our call today by answering a one question survey."`,
        actions: [
            "Wait for response",
            "If YES: 'Thank you so much! I'm going to forward the call now.' Then hang up",
            "If NO: 'Okay, no worries, thank you so much! Have a great day.' Let patient hang up"
        ],
        branches: [],
        keywords: ["survey", "rate", "experience", "one question", "end call"],
        notes: "This is the final step of the call flow"
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = callFlowSteps;
}