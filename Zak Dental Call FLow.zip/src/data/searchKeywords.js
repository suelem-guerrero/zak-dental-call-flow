// Search Keywords Mapping
const searchKeywords = {
    // Greeting related
    "greeting": [1, "1a", "1b"],
    "hello": ["1a", "1b"],
    "inbound": [1, "1a"],
    "callback": [1, "1b"],
    "thank you": ["1a"],
    "call type": [1],
    
    // Information gathering
    "name": [2],
    "phone": [2],
    "caller": [2],
    "information": [2, 15],
    "concern": [2],
    
    // Location
    "location": [3, "3b"],
    "office": [3, "3b"],
    "convenient": [3],
    "address": [3],
    "area": ["3b"],
    "closest": ["3b"],
    
    // Scheduling
    "schedule": [4, "4b", 8, 9, 11],
    "appointment": [4, "4b", 8, 9, "9b", 11, 17, 18],
    "ready": [4, "4b"],
    "not ready": ["4b"],
    
    // Specialty
    "specialty": [5, 6, 7, "7b", "7c", 8, "8b"],
    "referral": [5, 7, "8b", 16],
    "endodontics": [5],
    "oral surgery": [5],
    "referred": [5],
    
    // Insurance
    "insurance": [6, 10, 12, 13, 14, 16, 17, 18],
    "carrier": [6],
    "in-network": [6, 7],
    "out-of-network": ["7b"],
    "plan": [6],
    "medicare": [13],
    "dental insurance": [10, 14],
    "medical insurance": [13],
    "hmo": [14, 16],
    "ppo": [14, 16],
    "policy holder": [16],
    "insurance card": ["7c", 17, 18],
    "benefits": ["7c", 13],
    
    // Age and demographics
    "age": [12],
    "date of birth": [12],
    "dob": [12],
    "1959": [12, 13],
    "1960": [12, 14],
    "medicare advantage": [13],
    "65": [13, 14],
    "under 65": [14],
    "ssn": [13, 14, 16],
    "social security": [13, 14, 16],
    
    // Family
    "family": [9, "9b"],
    "multiple": [9, "9b"],
    "yourself": [8, 9],
    "someone else": [8, 9],
    "children": ["9b"],
    "names": ["9b"],
    
    // No insurance
    "no insurance": [11],
    "self-pay": [11],
    
    // Personal information
    "personal information": [15],
    "chart": [15],
    "denticon": [15, 16],
    "referral source": [16],
    
    // Confirmation
    "recap": [17, 18],
    "confirmation": [17, 18],
    "confirmed": [18],
    "intake paperwork": [17, 18],
    "48 hour notice": [17],
    "picture id": [17, 18],
    "pregnancy": ["17b", "18b"],
    "medical clearance": ["17b", "18b"],
    "pregnant": ["17b", "18b"],
    
    // Wrap up
    "wrap up": [21, "21b", 22],
    "additional help": [21, "21b"],
    "anything else": [21],
    "survey": [22],
    "end call": [22],
    "rate": [22],
    "experience": [22],
    
    // Common actions
    "email": [7, "7c"],
    "photos": [7, "7c"],
    "contact@zakdental.com": [7, "7c"],
    "unclear": ["7c"],
    "verify": [6, "7c", 13, 15],
    "missing": ["8b"],
    "call back": ["4b", "7c", "8b"]
};

// Function to search for steps by keyword
function searchSteps(query) {
    const results = [];
    const queryLower = query.toLowerCase();
    
    // Direct keyword matches
    for (const [keyword, stepIds] of Object.entries(searchKeywords)) {
        if (keyword.includes(queryLower) || queryLower.includes(keyword)) {
            stepIds.forEach(stepId => {
                if (!results.find(r => r.stepId === stepId)) {
                    results.push({
                        stepId: stepId,
                        matchType: 'keyword',
                        matchedTerm: keyword,
                        step: callFlowSteps[stepId]
                    });
                }
            });
        }
    }
    
    // Search in step content
    for (const [stepId, step] of Object.entries(callFlowSteps)) {
        const searchText = (step.title + ' ' + step.script + ' ' + step.actions.join(' ')).toLowerCase();
        if (searchText.includes(queryLower) && !results.find(r => r.stepId === stepId)) {
            results.push({
                stepId: stepId,
                matchType: 'content',
                matchedTerm: query,
                step: step
            });
        }
    }
    
    return results;
}

// Quick search categories
const quickSearchCategories = {
    "Insurance Verification": ["insurance", "carrier", "in-network", "benefits"],
    "Scheduling": ["schedule", "appointment", "ready", "available"],
    "Specialty Referral": ["specialty", "referral", "endodontics", "oral surgery"],
    "Medicare": ["medicare", "65", "medicare advantage", "medical insurance"],
    "Family Appointments": ["family", "multiple", "children", "names"],
    "Call Wrap-up": ["wrap up", "survey", "additional help", "end call"],
    "Patient Information": ["personal information", "chart", "denticon"],
    "Location Help": ["location", "office", "convenient", "address"]
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { searchKeywords, searchSteps, quickSearchCategories };
}